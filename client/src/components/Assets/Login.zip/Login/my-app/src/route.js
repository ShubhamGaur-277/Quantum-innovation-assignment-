import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Login from "./component/Login/Login";
import Registration from "./component/Registration/Registration";
import UserList from "./component/UserTable/UserList";

const Routes = () => {
  const routes = createBrowserRouter([
    {
      path: "/",
      element: <UserList />,
    },
    {
      path: "login",
      element: <Login />,
    },
    {
      path: "registration",
      element: <Registration />,
    },
    {
      path: "*",
      element: <>Page Not Found</>,
    },
  ]);

  return <RouterProvider router={routes} />;
};

export default Routes;
