export const userData = [
    {
      name: 'John Doe',
      createdDate: '2021-05-01',
      role: 'Admin',
      status: 'Active',
    },
    {
      name: 'Jane Smith',
      createdDate: '2021-06-15',
      role: 'User',
      status: 'Inactive',
    },
    // Add more mock data as needed
  ];