// src/Register.js
import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {
  Form as BootstrapForm,
  Button,
} from "react-bootstrap";

const Register = () => {
  const initialValues = {
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    dob: "", // Initial value for Date of Birth
  };

  const validationSchema = Yup.object({
    username: Yup.string().required("Required"),
    email: Yup.string().email("Invalid email format").required("Required"),
    password: Yup.string().required("Required"),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password"), null], "Passwords must match")
      .required("Required"),
    dob: Yup.date().required("Required").nullable(), // Validation for Date of Birth
  });

  const onSubmit = (values, { setSubmitting, setErrors }) => {
    setTimeout(() => {
      // Simulate a registration request
      alert("Registration successful");
      setSubmitting(false);
    }, 500);
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2 className="text-center">SIGN UP</h2>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {({ isSubmitting, errors }) => (
            <Form className="form">
              {errors.server && (
                <div className="alert alert-danger">{errors.server}</div>
              )}
              <BootstrapForm.Group>
                <Field
                  type="text"
                  name="username"
                  placeholder="Username"
                  className="form-control"
                />
                <ErrorMessage
                  name="username"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group>
                <Field
                  type="email"
                  name="email"
                  placeholder="Email"
                  className="form-control"
                />
                <ErrorMessage
                  name="email"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group>
                <Field
                  type="password"
                  name="password"
                  placeholder="Password"
                  className="form-control"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group>
                <Field
                  type="password"
                  name="confirmPassword"
                  placeholder="Confirm Password"
                  className="form-control"
                />
                <ErrorMessage
                  name="confirmPassword"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group>
                <Field
                  type="date"
                  name="dob"
                  placeholder="Date of Birth"
                  className="form-control"
                />
                <ErrorMessage
                  name="dob"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <Button
                variant="primary"
                type="submit"
                disabled={isSubmitting}
                className="btn-block"
              >
                {isSubmitting ? "Registering..." : "Sign Up"}
              </Button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Register;
