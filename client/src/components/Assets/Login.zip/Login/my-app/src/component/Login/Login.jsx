import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {
  Form as BootstrapForm,
  Button,
} from "react-bootstrap";

const Login = () => {
  const initialValues = {
    username: "",
    password: "",
  };

  const validationSchema = Yup.object({
    username: Yup.string().required("Required"),
    password: Yup.string().required("Required"),
  });

  const onSubmit = (values, { setSubmitting, setErrors }) => {
    setTimeout(() => {
      // Simulate a login request
      if (values.username === "user" && values.password === "password") {
        alert("Login successful");
      } else {
        setErrors({ server: "Invalid username or password" });
      }
      setSubmitting(false);
    }, 500);
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2 className="text-center">SIGN IN</h2>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {({ isSubmitting, errors }) => (
            <Form className="form" >
              {errors.server && (
                <div className="alert alert-danger">{errors.server}</div>
              )}
              <BootstrapForm.Group>
                <Field
                  type="text"
                  name="username"
                  placeholder="Username"
                  className="form-control"
                />
                <ErrorMessage
                  name="username"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group>
                <Field
                  type="password"
                  name="password"
                  placeholder="Password"
                  className="form-control"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="text-danger"
                />
              </BootstrapForm.Group>

              <BootstrapForm.Group
                controlId="formBasicCheckbox"
                className="text-left"
              >
                <Field
                  type="checkbox"
                  name="rememberMe"
                  className="form-check-input"
                />
                <label className="form-check-label">Remember me</label>
              </BootstrapForm.Group>

              <Button
                variant="primary"
                type="submit"
                disabled={isSubmitting}
                className="btn-block"
              >
                {isSubmitting ? "Logging in..." : "Login"}
              </Button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Login;
