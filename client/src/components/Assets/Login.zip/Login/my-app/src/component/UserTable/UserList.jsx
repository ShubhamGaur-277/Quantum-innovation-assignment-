// src/App.js
import React, { useState } from 'react';
import UserTable from './UserTable';
import { userData } from './data';

const UserList = () => {
  const [data, setData] = useState(userData);

  const handleEdit = (user) => {
    // Handle edit logic here
    console.log('Edit user:', user);
  };

  const handleDelete = (user) => {
    // Handle delete logic here
    setData(data.filter((item) => item.name !== user.name));
  };

  return (
    <div style={{margin:"30px"}} >
      <UserTable data={data} onEdit={handleEdit} onDelete={handleDelete} />
    </div>
  );
};

export default UserList;
